from logic_gates import AND
from logic_gates import OR
from logic_gates import NOT
from logic_gates import XOR

and_gate = AND()
or_gate = OR()
not_gate = NOT()
xor_gate = XOR()

and_gate.train()
#or_gate.train()
#not_gate.train()
#xor_gate.train()
